from flask import Flask, request, redirect, render_template, session, send_file, url_for
from flask_mail import Mail, Message
import os
import random
import sqlite3
import io
import pandas as pd
import unicodedata
import re

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = '......@gmail.com'  # Replace with your email
app.config['MAIL_PASSWORD'] = os.getenv("EMAIL_PASSWORD")
mail = Mail(app)

def create_db():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            phone TEXT,
            password TEXT NOT NULL,
            role TEXT DEFAULT 'student'
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS scores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_name TEXT NOT NULL,
            subject TEXT NOT NULL,
            midterm_score REAL,
            final_score REAL,
            absent_days INTEGER,
            achievements TEXT
        )
    ''')
    conn.commit()
    conn.close()
create_db()

@app.route('/')
def home():
    return redirect('/login')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = get_user(username, password)
        if user:
            session['username'] = user[1]
            session['role'] = user[5]
            if user[5] == 'teacher':
                return redirect('/teacher_dashboard')
            else:
                return redirect('/student_dashboard')
        else:
            return render_template("login.html", error="❌ Sai tài khoản hoặc mật khẩu.")
    return render_template("login.html")

def to_alias(name):
    # Loại bỏ dấu tiếng Việt
    name = unicodedata.normalize('NFD', name)
    name = name.encode('ascii', 'ignore').decode('utf-8')
    # Chỉ giữ chữ cái và số, bỏ dấu cách
    name = re.sub(r'[^a-zA-Z0-9]', '', name)
    return name.lower()

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        phone = request.form['phone']
        password = request.form['password']
        role = request.form['role']
        confirm_password = request.form.get('confirm_password', '')

        if role == 'teacher' and confirm_password != 'gogo1111':
            return render_template("register.html", error="🔐 Mật khẩu xác nhận của giáo viên không đúng.")

        if not save_user(username, email, phone, password, role):
            return render_template("register.html", error="❌ Tên đăng nhập hoặc email đã tồn tại.")
        return redirect('/login')
    return render_template("register.html")

@app.route('/teacher_dashboard')
def teacher_dashboard():
    if session.get('role') != 'teacher':
        return redirect('/login')
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM scores")
    scores = cursor.fetchall()
    conn.close()
    return render_template("teacher_dashboard.html", username=session.get('username'), scores=scores)

@app.route('/student_dashboard')
def student_dashboard():
    if session.get('role') != 'student':
        return redirect('/login')
    return redirect('/student_chart')

@app.route('/teacher_input', methods=['GET', 'POST'])
def teacher_input():
    if session.get('role') != 'teacher':
        return redirect('/login')

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    cursor.execute("SELECT username FROM users WHERE role='student'")
    students_list = [row[0] for row in cursor.fetchall()]

    if request.method == 'POST':
        student_name = to_alias(request.form['student_name'])
        subject = request.form['subject']
        midterm_score = float(request.form['midterm_score'])
        final_score = float(request.form['final_score'])
        absent_days = int(request.form['absent_days'])
        achievements = request.form['achievements']

        try:
            cursor.execute('''
                INSERT INTO scores (student_name, subject, midterm_score, final_score, absent_days, achievements)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (student_name, subject, midterm_score, final_score, absent_days, achievements))
            conn.commit()
            conn.close()
            return redirect('/teacher/view_scores')
        except Exception as e:
            conn.close()
            return render_template("teacher_input.html", error=f"❌ Lỗi: {str(e)}", students=students_list)

    cursor.execute("SELECT * FROM scores")
    all_scores = cursor.fetchall()
    conn.close()
    return render_template("teacher_input.html", scores=all_scores, students=students_list)

@app.route('/teacher/view_scores')
def teacher_view_scores():
    if session.get('role') != 'teacher':
        return redirect('/login')
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM scores")
    scores = cursor.fetchall()
    conn.close()
    return render_template("view_scores.html", scores=scores)

@app.route('/teacher_edit/<int:score_id>', methods=['GET', 'POST'])
def edit_score(score_id):
    if session.get('role') != 'teacher':
        return redirect('/login')
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    if request.method == 'POST':
        data = (
            request.form['student_name'],
            request.form['subject'],
            request.form['midterm_score'],
            request.form['final_score'],
            request.form['absent_days'],
            request.form['achievements'],
            score_id
        )
        cursor.execute('''
            UPDATE scores SET student_name=?, subject=?, midterm_score=?, final_score=?, absent_days=?, achievements=? WHERE id=?
        ''', data)
        conn.commit()
        conn.close()
        return redirect('/teacher/view_scores')
    cursor.execute("SELECT * FROM scores WHERE id=?", (score_id,))
    score = cursor.fetchone()
    conn.close()
    return render_template("edit_score.html", score=score)

@app.route('/teacher_delete/<int:score_id>')
def delete_score(score_id):
    if session.get('role') != 'teacher':
        return redirect('/login')
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("DELETE FROM scores WHERE id=?", (score_id,))
    conn.commit()
    conn.close()
    return redirect('/teacher/view_scores')

@app.route('/view_scores')
def view_scores():
    if session.get('role') != 'student':
        return redirect('/login')
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM scores WHERE student_name=?", (session.get('username'),))
    scores = cursor.fetchall()
    subjects = [row[2] for row in scores]
    averages = [round(((row[3] or 0) + (row[4] or 0)) / 2, 2) for row in scores]
    conn.close()
    return render_template("student_chart.html", scores=scores, subjects=subjects, averages=averages)

@app.route('/search_student', methods=['GET'])
def search_student():
    students = None
    student_name = request.args.get('student_name', '').strip()
    if student_name:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE role='student' AND username LIKE ?", ('%' + student_name + '%',))
        students = cursor.fetchall()
        conn.close()
    return render_template('search_student.html', students=students)


@app.route('/student_score/<student_name>')
def student_score(student_name):
    student_alias = student_name.strip().lower()
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM scores")
    all_scores = cursor.fetchall()
    
    # ✅ So sánh alias hóa
    scores = [row for row in all_scores if to_alias(row[1]) == student_alias]

    subjects = [row[2] for row in scores]
    averages = [round(((row[3] or 0) + (row[4] or 0)) / 2, 2) for row in scores]
    conn.close()
    searched = True
    return render_template('student_score.html',
                           scores=scores,
                           subjects=subjects,
                           averages=averages,
                           searched=searched,
                           student_name=student_name)


app.jinja_env.globals.update(to_alias=to_alias)

@app.route('/student_score', methods=['POST'])
def student_score_redirect():
    student_name = request.form.get('student_name', '').strip()
    if student_name:
        alias_name = to_alias(student_name)
        return redirect(url_for('student_score', student_name=alias_name))
    return redirect('/student_dashboard')

@app.route('/student_chart', methods=['GET', 'POST'])
def student_chart():
    if session.get('role') != 'student':
        return redirect('/login')
    if request.method == 'POST':
        student_name = request.form.get('student_name', '').strip()
    else:
        student_name = request.args.get('student_name', '').strip() or session.get('username')
    searched = bool(student_name and student_name != session.get('username'))
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM scores WHERE LOWER(TRIM(student_name))=LOWER(TRIM(?))", (student_name,))
    scores = cursor.fetchall()
    subjects = [row[2] for row in scores]
    averages = [round(((row[3] or 0) + (row[4] or 0)) / 2, 2) for row in scores]
    conn.close()
    return render_template("student_chart.html", scores=scores, subjects=subjects, averages=averages, searched=searched)

@app.route('/export_excel')
def export_excel():
    conn = sqlite3.connect('database.db')
    df = pd.read_sql_query("SELECT * FROM scores WHERE student_name=?", conn, params=(session.get('username'),))
    conn.close()
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        df.to_excel(writer, index=False, sheet_name='Scores')
    output.seek(0)
    return send_file(output, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', download_name='scores.xlsx', as_attachment=True)

@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        contact = request.form.get('contact')
        email_found = get_email_by_contact(contact)

        if email_found:
            otp = str(random.randint(100000, 999999))
            session['otp'] = otp
            session['reset_email'] = email_found
            send_otp_email(email_found, otp)
            return redirect('/verify')
        else:
            return render_template("forgot_password.html", error="Email hoặc số điện thoại không tồn tại.")
    return render_template("forgot_password.html")

@app.route("/verify", methods=["GET", "POST"])
def verify_otp():
    if 'otp' not in session:
        return redirect("/forgot_password")
    if request.method == "POST":
        entered_otp = request.form.get("otp")
        if entered_otp == session.get("otp"):
            return redirect("/reset_password")
        else:
            return render_template("verify.html", error="Mã OTP không đúng!")
    return render_template("verify.html")

@app.route('/reset_password', methods=['GET', 'POST'])
def reset_password():
    if request.method == 'POST':
        new_password = request.form['password']
        email = session.get('reset_email')
        if update_password(email, new_password):
            session.pop('otp', None)
            session.pop('reset_email', None)
            return redirect('/login')
        else:
            return "<h3>❌ Không tìm thấy người dùng với email này.</h3>"
    return render_template("reset_password.html")

def get_user(username, password):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, password))
    user = cursor.fetchone()
    conn.close()
    return user

def send_otp_email(to_email, otp):
    msg = Message("Mã OTP đặt lại mật khẩu", sender=app.config['MAIL_USERNAME'], recipients=[to_email])
    msg.body = f"Mã OTP của bạn là: {otp}"
    mail.send(msg)

def save_user(username, email, phone, password, role):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO users (username, email, phone, password, role) VALUES (?, ?, ?, ?, ?)",
                       (username, email, phone, password, role))
        conn.commit()
        conn.close()
        return True
    except sqlite3.IntegrityError as e:
        conn.close()
        return False

def update_password(email, new_password):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET password = ? WHERE email = ?", (new_password, email))
    conn.commit()
    affected = cursor.rowcount
    conn.close()
    return affected > 0

def get_email_by_contact(contact):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT email FROM users WHERE email = ? OR phone = ?", (contact, contact))
    result = cursor.fetchone()
    conn.close()
    return result[0] if result else None

if __name__ == "__main__":
    print("✅ Flask đang chạy tại http://127.0.0.1:5000")
    app.run(debug=True)